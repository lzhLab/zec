#include "correct_errors.hpp"
#include "stdint.h"
#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <cmath>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <sstream>
using namespace std;

typedef uint8_t BitType;


const int HASH_NUM=32;
const string DNA="ACGT";
const int TKz_Size=100;

const string BitFilePrefix="bit_";
const string LastFile = "last_file";
const string TempFile01= "tmp_file01";
const string TempFile02= "tmp_file02";



const unsigned int HashSeeds[HASH_NUM]=
{
	86028157,86941489,87866957,88799033,89743943,90695933,91657987,92632703,
	93617369,94610833,95612849,96628801,97653247,98690023,99740651,100801609,
	101870663,102948731,104041079,105144551,106262993,107388563,108525269,109676867,
	110842351,112019693,113206337,114410599,115627249,116852959,118092629,119349731
};

#define random(x) (rand()%x)  //random funtion 



//save kmer,occurrence and index temporarily
class TKzData{
public:
	int index;
	string kmer;
	short occurrence;
};


class Zdata{
public:
	int* hashFunIndexs; // the array to save hash function indexs
	BitType *bits1; // the bit vector
	BitType *bits2; // the flag vector
};



/***
	ZModel contains two important array bit1 and bits2,through them we can easily find occurrence by related kmer
***/
class ZModel{

private:

	int hashNumber; //the hash number is also bitIntOcc
	int bitIntOcc; // the bin-bit number to save a occurrence
	int bitIntVec; //the bit number bin to extend bit vector e.g uint8_t has 8 bin bits
	int *hashFunIndexs; //save the index of HashSeeds
	uint64_t tableBitSize; //the total bit size of the vector
	uint64_t *lows; //save the lowest bit when occurrence turn into bitIntOcc bit bin
	uint64_t *indexs; //the index of hashtable
	int tableSize; //default is the vector's size
	int maxOcc; // the max kmer occcurrence that hashfuntion can save 
	int minLastFileSizeM; //the mini size of last file(M) when less than it,the data will save to map directly
	int bitGenNumber; //the number of bit-generated file
	BitType *bits1; // the bit vector
	BitType *bits2; // the flag vector
	unordered_map<uint64_t, BitType> umap; //save the last file data
	vector<Zdata> vecZdata; //save bit-vectors
	

	//make bits1 and bits2 0
	void clearBitVector();
	//save the last date to umap
	void save2Map(string file);
	//travel each bit_file to find the occurrence by kmer
	int TravaBits(string file,string kmer);
	//travel each bit vector in memory to find the occurrence by kmer
	int TravaBits(int index,string kmer);
	// add a zdata to vecZdata
	void addZdata2Vector();


public:

	static int totalConflict;

	ZModel(uint64_t tableSize);
	//update Hash function index
	void updateHashFunIndex();
	//generate bit vector recursivly
	void generateBitTable(string inFile,string outFile,int level);
	//initate the bit vector from file
	void initBitTable(string file);
	//initate the bit vector from KMC
	void initBitTable(CKMCFile *kmer_database,CKmerAPI kmer,int kmer_length);
	//obtain the indexs array by mapping kmer
	void getHashIndexs(string kmer,int occurrence);
	//whether current kmer can insert into the vector 
	bool canIn2BitVector();
	// kmer insert into  the vector 
	void kmerIn2BitVector();
	//save the bit vector to file
	void saveBits2File(int level);
	//delete the temporay files
	void deleteTempFile();
	//get the ooccurrence by kmer
	int getOccByKmer(string kmer);
	//get the maximum occcurrence
	int getMaxOcc();
	// free the vector memory
	void deleteVectorZdata();

};



class Tools{
public:
	//set the postion of vector as one 
	static void setBitArry(BitType *bits,uint64_t pos,int bitIntVec);
	//to check the position in the bit is one or zero 
	static bool isValid(const BitType *bits,uint64_t pos,int bitIntVec);
	//get the size of the file 
	static uint64_t getFileSize(string file);
	//get the total line number of the file 
	static int getLineNumber(string file);
	//int -> string
	static string int2String(int numer);
	//kmer string -> int64
	static uint64_t kmers2uint64(string kmer);
	//hash function
	static uint64_t murmurHash64(const void * key, int len, unsigned int seed);
	//the bin of length -> the value of decimal
	static int bin2Decimal(short *arr,int length);
	//kmer -> Reverse Complement kmer
	static string getReverseComplement(string kmer);
	//CKmerAPI kmer -> string kmer
	static string toString(CKmerAPI kmer,int kmer_length);
};


/***
	Zscore:compute each kmer's zscore,in this case,we define an array that a bit represents a kmer solid or not 
***/
class Zscore{
private:
	double z0; 
	double z1;
	ZModel* zmodel;
	int threshold;
	BitType *bitsFlag; //bit flag to save whether the kmer is solid or not
	double getZscore(string kmer,int occurrence);

public:
	Zscore(ZModel* zmodel,int threshold,double z0,double z1);	
	//get kmer from CKMCFile(kmc)
	void initZscore(CKMCFile *kmer_database,CKmerAPI kmer,int kmer_length);
	//set  arrary bitsFlag by TKzData
	void setSolidBitsFlag(TKzData tdata);
	//return this->bitsFlag
	BitType* getBitsFlag();
};		
