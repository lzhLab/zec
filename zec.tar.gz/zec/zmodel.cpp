
#include "zmodel.hpp"

/****************************ZModel**********************************/

ZModel::ZModel(uint64_t tableSize){
	//init some parameters
	bitIntOcc=9;
	bitIntVec=8;
	this->hashNumber=this->bitIntOcc;
	bitGenNumber=0;
	lows=new uint64_t[bitIntOcc];
	indexs=new uint64_t[bitIntOcc];
	hashFunIndexs=new int[bitIntOcc];
	memset(hashFunIndexs,-1,bitIntOcc*sizeof(int));
	this->tableSize=tableSize;
	tableBitSize=tableSize*bitIntVec; 
	cout<<"tableBitSize:"<<tableBitSize<<endl;
	maxOcc=(1<<bitIntOcc)-1; 
	minLastFileSizeM=1024*1024*64;
};


int ZModel::getMaxOcc(){
	return this->maxOcc;
}


void ZModel::updateHashFunIndex(){
	int i,index;
	for(i=0;i<bitIntOcc;i++){
		while(true){ //Ensure current index is different from last
			index=random(HASH_NUM);
			if(hashFunIndexs[i]!=index){
				hashFunIndexs[i]=index;
				break;
			}
		}
	}
}

void ZModel::clearBitVector(){
	memset(bits1,0,tableSize*sizeof(BitType));
	memset(bits2,0,tableSize*sizeof(BitType)); 
}

void ZModel::getHashIndexs(string kmer,int occurrence){
	BitType occ=(BitType)occurrence;
	int i,i2;
	for(i=0;i<bitIntOcc;i++){
		lows[i]=occ & 0x1;
		i2=hashFunIndexs[i]; 
		indexs[i]=Tools::murmurHash64(kmer.c_str(),kmer.size(),HashSeeds[i2])%tableBitSize; 
		occ>>=1;
	}
}


bool ZModel::canIn2BitVector(){
	//when the bits2'value is one and the bit in the occurrence is different from the bits1' value
	//we can insert this kmer
	int i,v1,v2;
	for(i=0;i<bitIntOcc;i++){
		v1=Tools::isValid(bits1,indexs[i],bitIntVec);
		v2=Tools::isValid(bits2,indexs[i],bitIntVec);
		if( v2 && v1!=lows[i]){
			return false; 
		}
	}
	return true;
}


void ZModel::kmerIn2BitVector(){
	for(int i=0;i<bitIntOcc;i++){
		if(lows[i]) { //if the lowest is one,set bit in this vector zero
			Tools::setBitArry(bits1,indexs[i],bitIntVec);
		}
		Tools::setBitArry(bits2,indexs[i],bitIntVec);
	}
}


void ZModel::saveBits2File(int level){
	bitGenNumber++;
	string file=BitFilePrefix+Tools::int2String(level);
	ofstream fout(file);
	//save current hash function index
	for(int i=0;i<bitIntOcc;i++){
		fout<<hashFunIndexs[i]<<" ";
	}
	fout<<endl;
	for(uint64_t i=0;i<tableSize;i++){
		fout<<(int)bits1[i]<<" "<<(int)bits2[i]<<endl;
	}
	fout.close();
}


void ZModel::addZdata2Vector(){
	Zdata zdata;
	zdata.hashFunIndexs=new int [hashNumber];
	memcpy(zdata.hashFunIndexs,this->hashFunIndexs,sizeof(int)*hashNumber);
	zdata.bits1= new BitType[tableSize];
	zdata.bits2= new BitType[tableSize];
	memcpy(zdata.bits1,this->bits1,sizeof(BitType)*tableSize);
	memcpy(zdata.bits2,this->bits2,sizeof(BitType)*tableSize);
	vecZdata.push_back(zdata);
}

void ZModel::initBitTable(CKMCFile *kmer_database,CKmerAPI kmer,int kmer_length){
	string tf1=TempFile01;
	string tf2=TempFile02;
	ofstream fout(tf1);
	string kmer_str;
	int occurrence;
	float occ;
	int t_max=-1;
	bits1=new BitType[tableSize]; 
	bits2=new BitType[tableSize];
	clearBitVector(); 
	updateHashFunIndex(); //update current file's hashfunction indexs
	while (kmer_database->ReadNextKmer(kmer,occ)){
		if(occ>t_max)t_max=occ;
		//kmer.to_string(kmer_str);
		kmer_str=Tools::toString(kmer,kmer_length);
		occurrence=occ;
		if(occurrence>maxOcc) occurrence=maxOcc; 
		getHashIndexs(kmer_str,occurrence);
		if(canIn2BitVector()){
			kmerIn2BitVector();
		}else{ //save to file
			fout<<kmer_str<<" "<<occurrence<<endl;
		}
	}
	saveBits2File(0);
	addZdata2Vector();
	fout.close();
	generateBitTable(tf1,tf2,1);
	remove(tf1.c_str()); //delete the temporary file
	remove(tf2.c_str());
	delete [] bits1; 
	delete [] bits2; 
}

void ZModel::generateBitTable(string inFile,string outFile,int level){
	uint64_t fileSize=Tools::getFileSize(inFile);
	cout<<setiosflags(ios::fixed)<<setprecision(3)<<"current file size: "<<fileSize/1024.0/1024<<"M"<<endl;
	if(fileSize<=minLastFileSizeM){//if current file size less than minLastFileSizeM,save it into map
		save2Map(inFile);
		rename(inFile.c_str(),LastFile.c_str());
		return;
	}
	string kmer;
	int occurrence;
	ifstream fin(inFile);
	ofstream fout(outFile);
	clearBitVector(); 
	updateHashFunIndex();
	while(fin>>kmer>>occurrence){ //if the occurrence define as BitType,there is a problem
		if(occurrence>maxOcc) occurrence=maxOcc; 
		getHashIndexs(kmer,occurrence);
		if(canIn2BitVector()){
			kmerIn2BitVector();
		}else{ //save to file
			fout<<kmer<<" "<<occurrence<<endl;
		}
	}
	saveBits2File(level);
	addZdata2Vector();
	fout.close();
	fin.close();
	generateBitTable(outFile,inFile,level+1);
}


void ZModel::save2Map(string file){
	ifstream fin(LastFile);
	if(!fin){
		puts("initLastFile---can't find the file!");
		exit(1); 
	}
	uint64_t key;
	int occurrence;
	string kmer;
	while (fin>>kmer>>occurrence){
		key=Tools::kmers2uint64(kmer);
		umap[key]=occurrence;
	}
	fin.close();
}

int ZModel::TravaBits(int index,string kmer){
	int i,i2;
	Zdata zdata=vecZdata[index];
	short* binArray=new short[hashNumber];
	bool isok=true; // the flag whether we can find the kmer in current array bit 
	for(i=0;i<hashNumber;i++){
		i2=zdata.hashFunIndexs[i]; //get current hash seed
		if(i2>=HASH_NUM){
			cout<<"i2 great than HASH_NUM"<<endl;
			exit(1);
		}
		uint64_t pos=Tools::murmurHash64(kmer.c_str(),kmer.size(),HashSeeds[i2])%tableBitSize;
		binArray[i]=Tools::isValid(zdata.bits1,pos,bitIntVec);
		if(Tools::isValid(zdata.bits2,pos,bitIntVec)==false){
			isok=false;
			break;
		}
	}
	if(isok){ //if can find the kmer,return the occurrence,or return -1 
		return Tools::bin2Decimal(binArray,hashNumber);
	}
	delete [] binArray;
	return -1;
}

int ZModel::totalConflict=0;

int ZModel::getOccByKmer(string kmer){
	//find from bit array
	int i,j,occ=-1,max=-1,currentConflict=0;
	uint64_t pos,key;
	int n=vecZdata.size();
	//return the max occurence in the travel
	for(i=0;i<n;i++){
		occ=TravaBits(i,kmer);
		if(occ>-1){currentConflict++;} //can find freqence in this bit array 
		if(max<occ){
			max=occ;
		}
	}
	//find from map 
	key=Tools::kmers2uint64(kmer);
	unordered_map<uint64_t, BitType>::iterator it=umap.find(key);
	if(it!=umap.end()){
		occ=it->second;
		if(occ>-1){currentConflict++;} //can find freqence in this bit array 
		if(max<occ){
			max=occ;
			currentConflict++;
		}
	}
	if(currentConflict>=2){ // The current travel has conflicted
		totalConflict++;
	}
	return max;
}


void ZModel::deleteVectorZdata(){
	int n=vecZdata.size();
	for(int i=0;i<n;i++){
		delete [] (vecZdata[i].bits1);
		delete [] (vecZdata[i].bits2);
	}
}

/*
void ZModel::initBitTable(string file){
	ifstream fin(file);
	if(!fin){
		cout<<"cant't find the file "<<file<<endl;
		exit(1);
	}
	string tf1=TempFile01;
	string tf2=TempFile02;
	ofstream fout(tf1);
	string kmer;
	int occurrence;
	bits1=new BitType[tableSize]; 
	bits2=new BitType[tableSize];
	clearBitVector(); 
	updateHashFunIndex(); //update current file's hashfunction indexs
	while (fin>>kmer>>occurrence){
		if(occurrence>maxOcc) occurrence=maxOcc; 
		getHashIndexs(kmer,occurrence);
		if(canIn2BitVector()){
			kmerIn2BitVector();
		}else{ //save to file
			fout<<kmer<<" "<<occurrence<<endl;
		}
	}

	saveBits2File(0);
	fout.close();
	fin.close();
	generateBitTable(tf1,tf2,1);
	remove(tf1.c_str()); //delete the temporary file
	remove(tf2.c_str());
}


//get occurence from file,but not efficient
int ZModel::TravaBits(string file,string kmer){
	ifstream fin(file);
	if(!fin){
		cout<<"read bit file---cant't find the file "<<file<<endl;
		exit(1);
	}
	hashFunIndexs=new int[hashNumber];
	int i,i2;
	uint64_t pos;
	for(i=0;i<hashNumber;i++){
		fin>>hashFunIndexs[i];
	}
	int b1,b2,index=0;
	while (fin>>b1>>b2){
		bits1[index]=b1;
		bits2[index++]=b2;
	}
	fin.close();
	short* binArray=new short[hashNumber];
	bool isok=true; 
	for(i=0;i<hashNumber;i++){
		i2=hashFunIndexs[i];
		pos=Tools::murmurHash64(kmer.c_str(),kmer.size(),HashSeeds[i2])%tableBitSize;
		binArray[i]=Tools::isValid(bits1,pos,bitIntVec);
		if(Tools::isValid(bits2,pos,bitIntVec)==false){
			isok=false;
			break;
		}
	}
	if(isok){ //if can find the kmer,return the occurrence,or return -1 
		return Tools::bin2Decimal(binArray,hashNumber);
	}
	return -1;
}

int ZModel::getOccByKmer(string kmer){
	//find from zmodel
	int i,j,i2,occ=-1,value;
	uint64_t pos,key;
	int* hashFunIndexs;
	for(i=0;i<bitGenNumber;i++){
		string bitFile=BitFilePrefix+Tools::int2String(i);
		occ=TravaBits(bitFile,kmer);
		if(occ!=-1){
			return occ;
		}
	}
	//find from map 
	key=Tools::kmers2uint64(kmer);
	unordered_map<uint64_t, BitType>::iterator it=umap.find(key);
	if(it!=umap.end()){
		occ=it->second;
	}
	return occ;
}
*/


void ZModel::deleteTempFile(){
	string bitFile;
	for(int i=0;i<bitGenNumber;i++){
		bitFile=BitFilePrefix+Tools::int2String(i);
		remove(bitFile.c_str());
	}
	remove(LastFile.c_str());
}




/******************Tools class**************************************/

uint64_t Tools::murmurHash64(const void * key, int len, unsigned int seed)
{
	const uint64_t m = 0xc6a4a7935bd1e995;
	const int r = 47;
	uint64_t h = seed ^ (len * m);
	const uint64_t * data = (const uint64_t *)key;
	const uint64_t * end = data + (len/8);
	while(data != end)
	{
		uint64_t k = *data++;
		k *= m; 
		k ^= k >> r; 
		k *= m;
		h ^= k;
		h *= m; 
	}

	const unsigned char * data2 = (const unsigned char*)data;

	switch(len & 7)
	{
	case 7: h ^= uint64_t(data2[6]) << 48;
	case 6: h ^= uint64_t(data2[5]) << 40;
	case 5: h ^= uint64_t(data2[4]) << 32;
	case 4: h ^= uint64_t(data2[3]) << 24;
	case 3: h ^= uint64_t(data2[2]) << 16;
	case 2: h ^= uint64_t(data2[1]) << 8;
	case 1: h ^= uint64_t(data2[0]);
		h *= m;
	};

	h ^= h >> r;
	h *= m;
	h ^= h >> r;

	return h;
} 


string Tools::getReverseComplement(string kmer){
	int length=kmer.length();
	string result="";
	for(int i=length-1;i>=0;i--){
		switch(kmer[i]) {
		case 'A':	result+="T"; break;
		case 'C':	result+="G"; break;
		case 'G': 	result+="C"; break;
		case 'T': 	result+="A";
		}
	}
	return result;
}

uint64_t Tools::getFileSize(string file){ 
	ifstream in(file);   
	if(!in){
		puts("getFileSize---can't find the file!");
		exit(1); 
	}
	in.seekg(0,ios::end);   
	uint64_t size = in.tellg();
	in.close(); 
	return size;  
}

int Tools::getLineNumber(string file){
	ifstream in(file);   
	if(!in){
		puts("getLineNumber--can't find the file!");
		exit(1); 
	}
	int line=0;
	string str;
	while(getline(in,str)){
		++line;
	}
	in.close();
	return line;  
}

string Tools:: int2String(int numer){
	stringstream ss;
	ss<<numer; 
	return ss.str();
}

uint64_t Tools::kmers2uint64(string kmer){
	uint64_t v = 0;
	for (int i = 0; kmer[i]; i++) {
		v <<= 2;
		char x = toupper(kmer[i]);
		switch(x) {
		case 'A': ;       break;
		case 'C': v |= 1; break;
		case 'G': v |= 2; break;
		case 'T': v |= 3; 
		}
	}
	return v;
}
int Tools::bin2Decimal(short *arr,int length){
	int x=0; 
	for(int i=length-1;i>=0;i--){
		x<<=1;
		x|=arr[i];	
	} 
	return x;
}


void Tools::setBitArry(BitType *bits,uint64_t pos,int bitIntVec){
	//just regard the method of store as a table 
	int row=pos/bitIntVec;
	int col=pos%bitIntVec;
	BitType x = 0x1 << (bitIntVec - col - 1); //set the bit in the column in the table 
	bits[row] |= x;
}


bool Tools::isValid(const BitType *bits,uint64_t pos,int bitIntVec){
	int row = pos / bitIntVec;
	int col = pos % bitIntVec;
	return (bits[row]>>(bitIntVec - col - 1)) & 0x1;
}

string Tools::toString(CKmerAPI kmer,int kmer_length){
	string kmer_string;
	kmer.to_string(kmer_string);
	return kmer_string.substr(0, kmer_length);
} 


/******************************Zscore**************************************/


Zscore::Zscore(ZModel* zmodel,int threshold,double z0,double z1){
	this->z0= z0; //0.5;
	this->z1= z1;//-0.5;
	this->zmodel=zmodel;
	this->threshold=threshold;
}


double Zscore::getZscore(string kmer,int occurrence){
	vector<short> vx;
	string kmer2=kmer;
	int occ=-1;
	vx.push_back(occurrence); //let the origial kmer into the vector
	for(int i=0;kmer[i];i++){
		for(int j=0;j<4;j++){
			if(kmer2[i]!=DNA[j]){
				kmer[i]=DNA[j];
				occ=zmodel->getOccByKmer(kmer);
				if(occ>-1){
					vx.push_back(occ);
				}else{ //check the reverse complement
					string rc=Tools::getReverseComplement(kmer);
					occ=zmodel->getOccByKmer(rc);
					if(occ>-1){
						vx.push_back(occ);
					}
				}
			}
		}
		kmer[i]=kmer2[i];
	}
	int n=vx.size();
	if(n<=1){
		return 0;
	}
	double average,sum=0,dif;
	for(int i=0;i<n;i++){
		sum+=vx[i]; 
	}
	average=sum/n;
	sum=0;
	for(int i=0;i<n;i++){
		dif=vx[i]-average;
		sum+= dif*dif;
	}
	vector<short>(vx).swap(vx);//free the memory
	double std=sqrt(sum/(n-1));
	//if the std is 0,return the zscore 0 
	return std==0 ? 0:(occurrence-average)/std;

}

void Zscore::setSolidBitsFlag(TKzData tdata) {
	double zscore=getZscore(tdata.kmer,tdata.occurrence);
	//if((zscore>0.7 && zscore<0.75)|| (zscore>-0.75 && zscore<-0.7))
	//	return ;
	if(tdata.occurrence>=threshold && zscore>=z1){
		Tools::setBitArry(bitsFlag,tdata.index,8);
	} 
	if(tdata.occurrence<=threshold && zscore>z0){
		Tools::setBitArry(bitsFlag,tdata.index,8);
	}
} 

void Zscore::initZscore(CKMCFile *kmer_database,CKmerAPI kmer,int kmer_length){
	int kmersCount=kmer_database->KmerCount();
	int size=kmersCount/8+1; //bitvector is 8 bit
	bitsFlag=new BitType[size];
	memset(bitsFlag,0,size*sizeof(BitType));
	string kmer_str;
	float occ;
	//the buffere array,it's size is TKz_Size(default:100) in order to accelerate the run 
	TKzData *tdata=new TKzData[TKz_Size];
	int index=0,i2=0;
	int maxOcc=zmodel->getMaxOcc();
	//setSolidBitsFlag include the process computing zscore,and it is time-consuming.Therefore,firstly we save the kmer information into tdata,
	//and each 100 times we use openMP compute the zscore concurrently
	while (kmer_database->ReadNextKmer(kmer,occ)){
		if(occ>maxOcc) occ=maxOcc; 
		kmer_str=Tools::toString(kmer,kmer_length);
		tdata[index].index=i2;
		tdata[index].occurrence=occ;
		tdata[index].kmer=kmer_str;
		index++;
		if(index>=TKz_Size){ //get the size of buffere
#pragma omp parallel for
			for(int i=0;i<index;i++){
				setSolidBitsFlag(tdata[i]); 
			}
			index=0;
		}
		++i2;
		if(index<TKz_Size && i2>=kmersCount){// handle the rest
#pragma omp parallel for
			for(int i=0;i<index;i++){
				setSolidBitsFlag(tdata[i]); 
			}
		}
	}
	delete [] tdata;
}


BitType* Zscore::getBitsFlag(){
	return this->bitsFlag;
}

/************************TEST***************************/
